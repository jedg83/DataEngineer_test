# Copyright (c) 2010-2024 openpyxl

from .rule import Rule
